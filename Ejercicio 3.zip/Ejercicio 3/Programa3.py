numero_casos = input('Ingrese el número de casos: ')
numero = 0
lista_saltos = []
contador = 0
saltos = 0
valor_numero = []
valor_saltos = []

def calcular_saltos(numero):
    global contador, saltos, lista_saltos, valor_numero, valor_saltos
    for x in valor_numero:
        if (numero == x):
            lista_saltos.append(valor_saltos[x])
            saltos = valor_saltos[x] - 1
        else:
            contador += (contador+1)
            saltos += 1
            if (contador == numero):
                valor_numero.append(contador)
                valor_saltos.append(saltos)
                lista_saltos.append(saltos)
                print(lista_saltos)
            else:
                if (contador > numero):
                    valor_numero.append(contador)
                    valor_saltos.append(saltos)
                    contador -= 1
                    saltos += 1
                    if (contador == numero):
                        valor_numero.append(contador)
                        valor_saltos.append(saltos)
                        lista_saltos.append(saltos)
                        print(lista_saltos)
                    if (contador <  numero):
                        contador += 1
                        saltos += 1
                        if (contador == numero):
                            lista_saltos.append(saltos)
                            print(lista_saltos)

while numero < int(numero_casos):
    caso = input('Entero para la prueba número ' + str(numero+1) +': ')
    calcular_saltos(int(caso))
    numero += 1
    



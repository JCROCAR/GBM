Instrucciones para correr el programa:
1. El programa solicitará el número de casos a ejecutar, por lo que deberá ingresarlos.
2. Seguido de eso, tendrá que ingresar un número entero por cada caso. 
3. Se imprimirá el número de saltos para alcanzar dicho número.
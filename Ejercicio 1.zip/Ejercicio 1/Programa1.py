def es_palindromo(texto=input()):
    texto_original = list(texto)
    texto_inverso = list(reversed(texto))
    if (texto_original==texto_inverso): return True
print('Es palindromo') if es_palindromo() else print('No es palindromo')



Instrucciones para correr el programa:
1. Ejecutar el programa
2. Ingresar la palabra a utilizar para comprobar si es un palíndromo o no. 
3. El programa retonará el texto 'Es palíndromo' o 'No es palíndromo' según sea el caso.